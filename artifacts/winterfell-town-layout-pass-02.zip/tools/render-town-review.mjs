// Inspect the actual exported GLB with installed Three.js in isolated Chrome.
// All requests are fulfilled from local files; the application is untouched.
import { chromium } from '@playwright/test';
import { readFile,writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
const files={
  '/vendor/three.module.js':'node_modules/three/build/three.module.js',
  '/vendor/three.core.js':'node_modules/three/build/three.core.js',
  '/vendor/GLTFLoader.js':'node_modules/three/examples/jsm/loaders/GLTFLoader.js',
  '/utils/BufferGeometryUtils.js':'node_modules/three/examples/jsm/utils/BufferGeometryUtils.js',
  '/utils/SkeletonUtils.js':'node_modules/three/examples/jsm/utils/SkeletonUtils.js',
  '/scene.glb':'public/assets/winterfell-town/winterfell_fortress.glb'
};
const html=`<!doctype html><html><head><style>body{margin:0;background:#8e9fa9}canvas{display:block}</style><script type="importmap">{"imports":{"three":"/vendor/three.module.js"}}</script></head><body><script type="module">
import * as THREE from 'three';
import {GLTFLoader} from '/vendor/GLTFLoader.js';
const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});
renderer.setSize(1600,1200);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;renderer.toneMapping=THREE.ACESFilmicToneMapping;
document.body.append(renderer.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color('#99aab4');
// At this town-wide distance a 2 m near plane preserves depth separation
// between the snow surface and the frozen base beneath it.
const camera=new THREE.PerspectiveCamera(42,4/3,2,1500);camera.position.set(252,247,307);camera.lookAt(0,7,0);
scene.add(new THREE.HemisphereLight('#d8e9f3','#424949',1.65));
const sun=new THREE.DirectionalLight('#e5eff7',2.4);sun.position.set(-90,180,80);sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-170,right:170,top:170,bottom:-170,far:500});sun.shadow.bias=-.0001;sun.shadow.normalBias=.1;scene.add(sun);
new GLTFLoader().load('/scene.glb',async gltf=>{
 let meshes=0,missingMaterials=0;const materials=new Set();
 gltf.scene.traverse(o=>{if(o.isMesh){meshes++;o.castShadow=true;o.receiveShadow=true;if(!o.material)missingMaterials++;else materials.add(o.material.uuid);}});
 scene.add(gltf.scene);const bounds=new THREE.Box3().setFromObject(gltf.scene);const size=bounds.getSize(new THREE.Vector3());
 await renderer.compileAsync(scene,camera);renderer.render(scene,camera);
 window.__review={loaded:true,meshes,materials:materials.size,missingMaterials,bounds:[size.x,size.y,size.z],drawCalls:renderer.info.render.calls,renderedTriangles:renderer.info.render.triangles};
},undefined,error=>{window.__loadError=String(error);});
</script></body></html>`;
const browser=await chromium.launch({channel:'chrome',headless:true});
try{
 const page=await browser.newPage({viewport:{width:1600,height:1200}});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/*',async route=>{
  const pathname=new URL(route.request().url()).pathname;
  if(pathname==='/')return route.fulfill({contentType:'text/html',body:html});
  if(files[pathname])return route.fulfill({contentType:pathname.endsWith('.glb')?'model/gltf-binary':'text/javascript',body:await readFile(files[pathname])});
  return route.fulfill({status:404,body:'Not found'});
 });
 await page.goto('http://fortress-review.test/');
 await page.waitForFunction(()=>window.__review?.loaded || window.__loadError,{timeout:90000});
 const report=await page.evaluate(()=>({scene:window.__review,error:window.__loadError}));
 assert.equal(report.error,undefined);assert.equal(errors.length,0,JSON.stringify(errors));
 assert.equal(report.scene.missingMaterials,0);assert.ok(report.scene.meshes>=7);
 assert.ok(report.scene.bounds[0]>=478 && report.scene.bounds[2]>=478);
 await page.screenshot({path:'artifacts/layout-pass-02/glb-review.png'});
 await writeFile('artifacts/layout-pass-02/browser-glb-validation.json',JSON.stringify({passed:true,...report,errors},null,2));
 console.log(JSON.stringify(report,null,2));
}finally{await browser.close();}
